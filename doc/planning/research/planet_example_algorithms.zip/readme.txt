libnoise examples - differences between 0.9.0 and 0.9.0.1

- Since the noiseutils library is part of the noise namespace, these
  examples now use that namespace.
